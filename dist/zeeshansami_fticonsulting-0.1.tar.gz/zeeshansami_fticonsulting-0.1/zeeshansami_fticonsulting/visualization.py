import plotly.data as data
import plotly.express as px

# Data Handling
def load_carshare_data():
    return data.carshare()

# Visualization Functions
def barchart_carsharedata():
    dataframe = load_carshare_data()
    fig = px.histogram(dataframe, x="peak_hour", nbins=24, title="Car Count by Peak Hour")
    fig.show()

# if you want to run the function immediately when you run the python file
# uncomment the line below
# plot_car_count_by_peak_hour()
